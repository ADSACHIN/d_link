What is WinGUp for Notepad++?
--------------------------

This project is a fork of [WinGUp](https://github.com/gup4win/wingup) <br/>
WinGUp was originally built to meet the need of Notepad++, but its functionality was kept generic so it could be used with any Windows application. With the introduction of the built-in Plugins Admin in Notepad++, a more specific updater for Notepad++ become necessary. Hence this fork was created from the original WinGUp.

**Note:** [the original repository of WinGUp](https://github.com/gup4win/wingup) is no longer maintained. You can integrate ***WinGUp for Notepad++***, which provides the basic updating feature, into your project.

What is WinGUp?
---------------

WinGUp is a Generic Updater running under Windows environment.
The aim of WinGUp is to provide a ready to use and configurable updater
which downloads a update package then installs it. By using cURL library
and TinyXml module, WinGUp is capable to deal with http protocol and process XML data.


Why WinGUp?
-----------

Originally WinGUp was made for the need of Notepad++ (a generic source code editor under MS Windows).
During its conception, the idea came up in my mind: if it can fit Notepad++, it can fit for any Windows program.
So here it is, with LGPL license to have no (almost not) restriction for integration in any project.



How does it work?
-----------------

WinGUp can be launched by your program or manually. It reads from a xml configuration file
for getting the current version of your program and url where WinGUp gets update information,
checks the url (with given current version) to get the update package location,
downloads the update package, then run the update package (it should be a msi or an exe) in question.



Who will need it?
-----------------

Being LGPLed, WinGUp can be integrated in both commercial (or close source) and open source project.
So if you run a commercial or open a source project under MS Windows and you release your program at
regular intervals, then you may need WinGUp to notice your users the new update.



What do you need to use it?
---------------------------

A url to provide the update information to your WinGUp and an another url location
to store your update package, that's it!



How is WinGUp easy to use?
--------------------------

All you have to do is point WinGUp to your url update page (by modifying gup.xml), 
then work on your pointed url update page (see getDownLoadUrl.php comes with the release)
to make sure it responds to your WinGUp with the correct xml data.



How to build it?
----------------

 * Step 1: You have to build cURL before building WinGUp:

    1. Open Visual Studio Native Tool Command.
    2. Go to WinGUp source directory and run "buildCurlAll.bat".

 * Step 2: Open [`vcproj\GUP.sln`](https://github.com/gup4win/wingup/blob/master/vcproj/GUP.sln) with VS2022.
 
 * Step 3: Build WinGUp like a normal Visual Studio project.


To whom should you say "thank you"?
-----------------------------------

Don HO
<don.h@free.fr>

